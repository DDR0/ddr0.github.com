#ifndef EDITOR_DIALOGS_HPP_INCLUDED
#define EDITOR_DIALOGS_HPP_INCLUDED
#ifndef NO_EDITOR

#include <string>

std::string show_choose_level_dialog(const std::string& prompt);

#endif // NO_EDITOR
#endif
