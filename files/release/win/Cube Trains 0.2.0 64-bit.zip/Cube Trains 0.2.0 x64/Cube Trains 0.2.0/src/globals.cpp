#include "globals.h"

int pause_stack = 0;
bool of_dashboard_visible = false;
