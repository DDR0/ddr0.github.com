#ifndef IPHONE_DEVICE_INFO_H_INCLUDED
#define IPHONE_DEVICE_INFO_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

void iphone_screen_res (int *w, int *h);
	
#ifdef __cplusplus
} //extern "C"
#endif

#endif
