#ifndef OF_BRIDGE_H
#define OF_BRIDGE_H

void of_init ();
void of_dashboard ();
void of_earn_achievement (int of_id);
void of_submit_score (int of_leaderboard_id, long score);

#endif
