#ifndef UTILITY_QUERY_HPP_INCLUDED
#define UTILITY_QUERY_HPP_INCLUDED

std::string modify_variant_text(const std::string& contents, variant original, variant v, int line=1, int col=1, std::string indent="");

#endif
