#ifndef CONTROLS_DIALOG_INCLUDED
#define CONTROLS_DIALOG_INCLUDED

void show_controls_dialog();

#endif
