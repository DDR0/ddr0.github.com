Open Pixel Platformer
=====================

An open-source pixel-art platformer game. (Alpha Test Edition™)

![A picture of the demo of OPP.](http://ddr0.github.io/images/forum%20posts/snapshot%20103.png "It has animations in-game!")

More information (and downloads) can be found on the [Pixel Joint forums](http://www.pixeljoint.com/forum/forum_posts.asp?TID=16828&PN=1). The Open Pixel Platformer is a module for the [Anura engine](https://github.com/anura-engine/anura/), the engine used to build [Frogatto & Friends](http://www.frogatto.com). Compiling details can be found at [frogatto.com/developer](http://www.frogatto.com/developer). If you encounter any problems, please drop us a line on the [frogatto forums](http://frogatto.com/forum/).

Enjoy!
