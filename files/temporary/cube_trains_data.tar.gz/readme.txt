This is a temporary replacement for the cube_trains configuration and resource files, and is covered under the same license that Cube Trains is.
For more details, please contact robertsdavidddr@gmail.com
